<?php
require __DIR__.'/includes/auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);header('Allow: POST');exit('Method Not Allowed');}
admin_verify_csrf();
$_SESSION=[];
if(ini_get('session.use_cookies')){
  $params=session_get_cookie_params();
  setcookie(session_name(),'',time()-42000,$params['path'],$params['domain']??'',(bool)$params['secure'],(bool)$params['httponly']);
}
session_destroy();
header('Location: login.php');
exit;
