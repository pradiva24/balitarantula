# Bali Tarantula Adventure — Stage 1 import

This package contains the Manuaba Portal admin folder from Archive(10).zip plus root index.php and selected includes/assets/config dependencies.

Safety exclusions: error logs, backup copies, macOS metadata, gsc-config.php, finalize-image-cleanup.php, SQL dump, and embedded DB password defaults.

Before deployment, configure database credentials via environment variables (BTA_DB_HOST, BTA_DB_PORT, BTA_DB_NAME, BTA_DB_USER, BTA_DB_PASS, BTA_BASE_URL). Payment gateway credentials should remain in the admin settings or server-side secret storage, not in Git.

This is an import bundle; PHP syntax validation and runtime integration tests are still required after import.
